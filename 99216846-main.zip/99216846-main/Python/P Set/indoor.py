yell = str(input())

print(yell.lower())