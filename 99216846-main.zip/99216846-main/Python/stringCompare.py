s = input("s: ")

t = s.capitalize()

