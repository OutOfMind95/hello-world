from sys import argv

for arg in argv[1:]:
    print(arg)