import random

def main():
    coin = random.choice(["heads", "tails"])
    print(coin)

main()