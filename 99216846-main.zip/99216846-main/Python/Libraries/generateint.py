import random

def main():
    number = random.randint(1, 10)
    print(number)

main()