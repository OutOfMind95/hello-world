import statistics

def main():
    print(statistics.mean([100, 90, 95, 93, 89, 90]))

main()