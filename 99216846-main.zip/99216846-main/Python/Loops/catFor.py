# for i in [0, 1, 2]:
for _ in range(3): # 0, 1, 2 [3 non compreso] _ (variabile senza un particolare nome)
   print("meow")