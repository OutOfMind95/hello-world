x = float(input("What's x? "))
y = float(input("What's y? "))

# round(number [, ndigit]) funzione arrotonda, *opzionale a che decimale (n)

print(round(x / y, 2))