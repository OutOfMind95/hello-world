#include <stdio.h>
#include <cs50.h>

int main(void)
/*{
    char c1 = 'H';
    char c2 = 'I';
    char c3 = '!';

        printf("%i %i %i\n", c1, c2, c3);
}*/
{
    string s = "HI!";
    string t = "BYE!";
    printf("%s\n", s);
    printf("%s\n", t);
}