typedef struct node
{
    char *number;
    struct node *children[26];
}
node;